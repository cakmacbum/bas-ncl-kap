/**
 * Vessela — ASME Section II Part D Allowable Stress Interpolation Module
 *
 * Rules implemented:
 * 1. Linear interpolation between tabulated temperature breakpoints
 *    (ASME Section II Part D, General Notes to Table 1A/1B).
 * 2. Strict prohibition on extrapolation above the highest tabulated temperature
 *    or material maxTempC.
 * 3. Direct native SI (Table 1A-M) or US Customary (Table 1A) lookup to avoid
 *    unit-conversion chain errors (~1–2% drift).
 * 4. Structured Result<T, MaterialError> return type so UI components never crash
 *    to a blank screen on invalid inputs.
 */

export type UnitSystem = 'SI' | 'US';

export type AsmeTableRef = '1A' | '1B' | '2A' | '2B';

export type Ucs66Curve = 'A' | 'B' | 'C' | 'D' | null;

export interface StressPointSI {
  tempC: number;
  stressMPa: number;
}

export interface StressPointUS {
  tempF: number;
  stressPsi: number;
}

export interface MaterialRecord {
  id: string;
  specNo: string;
  grade: string;
  uns: string;
  productForm: 'Plate' | 'Seamless Pipe' | 'Welded Pipe' | 'Forging' | 'Bar' | 'Tube';
  asmeTable: AsmeTableRef;
  pNumber: number | null;
  groupNumber: number | null;
  minTensileMPa: number;
  minYieldMPa: number;
  maxTempC: number;
  minTempC: number;
  ucs66Curve: Ucs66Curve;
  externalPressureChart: string;
  densityKgM3: number;
  notes?: string[];
  allowableStressSI: StressPointSI[];
  allowableStressUS?: StressPointUS[];
}

export interface MaterialDatabase {
  schemaVersion: string;
  codeEdition: string;
  materials: MaterialRecord[];
}

export type MaterialErrorCode =
  | 'MATERIAL_NOT_FOUND'
  | 'MISSING_UNIT_TABLE'
  | 'INVALID_CURVE_DATA'
  | 'TEMPERATURE_EXCEEDS_MAX'
  | 'TEMPERATURE_BELOW_MIN';

export interface MaterialError {
  code: MaterialErrorCode;
  message: string;
  materialId?: string;
}

export interface InterpolatedStressResult {
  materialId: string;
  specLabel: string;
  unitSystem: UnitSystem;
  temperature: number;
  allowableStress: number;
  stressUnit: 'MPa' | 'psi';
  isExactBreakpoint: boolean;
  lowerPoint: { temp: number; stress: number };
  upperPoint: { temp: number; stress: number };
  warnings: string[];
}

export type CalcResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: MaterialError };

interface CurvePoint {
  temp: number;
  stress: number;
}

function normalizeCurve(
  material: MaterialRecord,
  unitSystem: UnitSystem
): CalcResult<CurvePoint[]> {
  if (unitSystem === 'SI') {
    if (!material.allowableStressSI || material.allowableStressSI.length < 2) {
      return {
        ok: false,
        error: {
          code: 'INVALID_CURVE_DATA',
          materialId: material.id,
          message: `Material ${material.specNo} ${material.grade} lacks valid SI stress points.`,
        },
      };
    }
    const pts = material.allowableStressSI.map((p) => ({
      temp: p.tempC,
      stress: p.stressMPa,
    }));
    return validateSortedCurve(pts, material.id);
  }

  if (!material.allowableStressUS || material.allowableStressUS.length < 2) {
    return {
      ok: false,
      error: {
        code: 'MISSING_UNIT_TABLE',
        materialId: material.id,
        message: `Material ${material.specNo} ${material.grade} does not have a native US Customary (Table 1A/1B) curve.`,
      },
    };
  }

  const pts = material.allowableStressUS.map((p) => ({
    temp: p.tempF,
    stress: p.stressPsi,
  }));
  return validateSortedCurve(pts, material.id);
}

function validateSortedCurve(
  pts: CurvePoint[],
  materialId: string
): CalcResult<CurvePoint[]> {
  for (let i = 1; i < pts.length; i++) {
    if (pts[i].temp <= pts[i - 1].temp) {
      return {
        ok: false,
        error: {
          code: 'INVALID_CURVE_DATA',
          materialId,
          message: `Stress curve temperatures must be strictly ascending for ${materialId}.`,
        },
      };
    }
  }
  return { ok: true, data: pts };
}

/**
 * Computes allowable stress S at a given design or test temperature using
 * ASME Section II Part D linear interpolation.
 */
export function getAllowableStress(
  material: MaterialRecord,
  temperature: number,
  unitSystem: UnitSystem = 'SI'
): CalcResult<InterpolatedStressResult> {
  const curveRes = normalizeCurve(material, unitSystem);
  if (!curveRes.ok) return curveRes;

  const curve = curveRes.data;
  const first = curve[0];
  const last = curve[curve.length - 1];
  const stressUnit = unitSystem === 'SI' ? 'MPa' : 'psi';
  const specLabel = `${material.specNo} ${material.grade}`;
  const warnings: string[] = [];

  const minAllowedTemp =
    unitSystem === 'SI'
      ? material.minTempC
      : (material.minTempC * 9) / 5 + 32;

  if (temperature < minAllowedTemp) {
    return {
      ok: false,
      error: {
        code: 'TEMPERATURE_BELOW_MIN',
        materialId: material.id,
        message: `Design/MDMT temperature (${temperature}) is below minimum tabulated limit (${minAllowedTemp.toFixed(1)}) for ${specLabel}.`,
      },
    };
  }

  if (temperature > last.temp) {
    return {
      ok: false,
      error: {
        code: 'TEMPERATURE_EXCEEDS_MAX',
        materialId: material.id,
        message: `Temperature (${temperature}) exceeds highest tabulated value (${last.temp}) for ${specLabel}. Extrapolation is prohibited by ASME Section II Part D.`,
      },
    };
  }

  // Below ambient first breakpoint (e.g. -29°C to 40°C): ASME II-D holds ambient S constant
  if (temperature <= first.temp) {
    if (temperature < first.temp) {
      warnings.push(
        `Temperature (${temperature}) is below first stress breakpoint (${first.temp}); using ambient allowable stress (${first.stress} ${stressUnit}). Verify MDMT rules (UCS-66 / UHA-51).`
      );
    }
    return {
      ok: true,
      data: {
        materialId: material.id,
        specLabel,
        unitSystem,
        temperature,
        allowableStress: first.stress,
        stressUnit,
        isExactBreakpoint: temperature === first.temp,
        lowerPoint: first,
        upperPoint: first,
        warnings,
      },
    };
  }

  for (let i = 0; i < curve.length - 1; i++) {
    const p1 = curve[i];
    const p2 = curve[i + 1];

    if (temperature === p1.temp) {
      return {
        ok: true,
        data: {
          materialId: material.id,
          specLabel,
          unitSystem,
          temperature,
          allowableStress: p1.stress,
          stressUnit,
          isExactBreakpoint: true,
          lowerPoint: p1,
          upperPoint: p1,
          warnings,
        },
      };
    }

    if (temperature === p2.temp) {
      return {
        ok: true,
        data: {
          materialId: material.id,
          specLabel,
          unitSystem,
          temperature,
          allowableStress: p2.stress,
          stressUnit,
          isExactBreakpoint: true,
          lowerPoint: p2,
          upperPoint: p2,
          warnings,
        },
      };
    }

    if (temperature > p1.temp && temperature < p2.temp) {
      const ratio = (temperature - p1.temp) / (p2.temp - p1.temp);
      const interpolated = p1.stress + ratio * (p2.stress - p1.stress);

      return {
        ok: true,
        data: {
          materialId: material.id,
          specLabel,
          unitSystem,
          temperature,
          allowableStress: Number(interpolated.toFixed(3)),
          stressUnit,
          isExactBreakpoint: false,
          lowerPoint: p1,
          upperPoint: p2,
          warnings,
        },
      };
    }
  }

  return {
    ok: false,
    error: {
      code: 'INVALID_CURVE_DATA',
      materialId: material.id,
      message: `Unexpected lookup failure for ${specLabel} at ${temperature}.`,
    },
  };
}

/**
 * Helper for ASME VIII-1 UG-99 Hydrostatic Test Pressure:
 * P_test = 1.3 * MAWP * (S_test / S_design)
 */
export function getHydrotestStressRatio(
  material: MaterialRecord,
  designTemp: number,
  testTemp: number,
  unitSystem: UnitSystem = 'SI'
): CalcResult<{ sDesign: number; sTest: number; lsr: number }> {
  const designRes = getAllowableStress(material, designTemp, unitSystem);
  if (!designRes.ok) return designRes;

  const testRes = getAllowableStress(material, testTemp, unitSystem);
  if (!testRes.ok) return testRes;

  const lsr = Math.max(1.0, testRes.data.allowableStress / designRes.data.allowableStress);

  return {
    ok: true,
    data: {
      sDesign: designRes.data.allowableStress,
      sTest: testRes.data.allowableStress,
      lsr: Number(lsr.toFixed(4)),
    },
  };
}
