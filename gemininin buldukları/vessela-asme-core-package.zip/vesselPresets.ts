/**
 * Vessela — 01 Yeni Proje Başlangıç Şablonları (Starter Presets)
 *
 * Amaç:
 * - Kullanıcıya "boş formda ne gireceğim?" yükünü ortadan kaldırmak
 * - 01..06 adımlarının tamamını geçerli varsayılan değerlerle hydrate ederek
 *   eksik state kaynaklı beyaz ekran çökmelerini önlemek
 * - allowableStress.ts içindeki malzeme ID'leri ile birebir eşleşmek
 */

export type DesignCode = 'ASME_VIII_DIV_1' | 'EN_13445';
export type VesselOrientation = 'horizontal' | 'vertical';
export type HeadShape = 'ellipsoidal_2_1' | 'torispherical_fd' | 'hemispherical';

export interface NozzlePresetItem {
  tag: string;
  service: string;
  outsideDiameterMm: number;
  nominalThicknessMm: number;
  externalProjectionMm: number;
  internalProjectionMm: number;
  jointEfficiency: number;
  corrosionAllowanceMm: number;
}

export interface VesselProjectState {
  project: {
    projectNo: string;
    projectName: string;
    client: string;
    revision: string;
    designCode: DesignCode;
    codeEdition: string;
    orientation: VesselOrientation;
  };
  conditions: {
    operatingPressureMPa: number;
    designPressureMPa: number;
    externalPressureMPa: number;
    hasVacuum: boolean;
    operatingTempC: number;
    designTempC: number;
    mdmtC: number;
    corrosionAllowanceIntMm: number;
    corrosionAllowanceExtMm: number;
    fluidSpecificGravity: number;
    liquidLevelMm: number;
  };
  geometry: {
    materialId: string;
    insideDiameterMm: number;
    shellLengthTanToTanMm: number;
    shellNominalThicknessMm: number;
    jointEfficiencyLong: number;
    jointEfficiencyCirc: number;
    headType: HeadShape;
    headNominalThicknessMm: number;
    headJointEfficiency: number;
    straightFlangeMm: number;
    nozzles: NozzlePresetItem[];
  };
}

export interface VesselPreset {
  id: 'horizontal-air-receiver' | 'vacuum-process-tank' | 'vertical-separator';
  title: string;
  badge: string;
  summary: string;
  state: VesselProjectState;
}

export const VESSEL_PRESETS: readonly VesselPreset[] = [
  {
    id: 'horizontal-air-receiver',
    title: 'Yatay Hava Tankı',
    badge: 'ASME VIII-1 · Karbon Çelik',
    summary: '11 bar, 80 °C, Ø1000 mm × 2500 mm T/T, SA-516 Gr.70, 2:1 Elipsoidal Bombe',
    state: {
      project: {
        projectNo: 'PRJ-AIR-01',
        projectName: 'Yatay Basınçlı Hava Tankı',
        client: 'Standart Şablon',
        revision: 'R0',
        designCode: 'ASME_VIII_DIV_1',
        codeEdition: '2025',
        orientation: 'horizontal',
      },
      conditions: {
        operatingPressureMPa: 0.95,
        designPressureMPa: 1.1,
        externalPressureMPa: 0,
        hasVacuum: false,
        operatingTempC: 60,
        designTempC: 80,
        mdmtC: -10,
        corrosionAllowanceIntMm: 2.0,
        corrosionAllowanceExtMm: 0,
        fluidSpecificGravity: 0,
        liquidLevelMm: 0,
      },
      geometry: {
        materialId: 'sa-516-gr70',
        insideDiameterMm: 1000,
        shellLengthTanToTanMm: 2500,
        shellNominalThicknessMm: 8,
        jointEfficiencyLong: 0.85,
        jointEfficiencyCirc: 0.85,
        headType: 'ellipsoidal_2_1',
        headNominalThicknessMm: 8,
        headJointEfficiency: 1.0,
        straightFlangeMm: 40,
        nozzles: [
          {
            tag: 'N1',
            service: 'Hava Girişi (DN100)',
            outsideDiameterMm: 114.3,
            nominalThicknessMm: 6.02,
            externalProjectionMm: 150,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 2.0,
          },
          {
            tag: 'N2',
            service: 'Hava Çıkışı (DN100)',
            outsideDiameterMm: 114.3,
            nominalThicknessMm: 6.02,
            externalProjectionMm: 150,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 2.0,
          },
          {
            tag: 'N3',
            service: 'Kondens Tahliye (DN50)',
            outsideDiameterMm: 60.3,
            nominalThicknessMm: 5.54,
            externalProjectionMm: 120,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 2.0,
          },
        ],
      },
    },
  },
  {
    id: 'vacuum-process-tank',
    title: 'Vakumlu Proses Tankı',
    badge: 'ASME VIII-1 · Tam Vakum',
    summary: '3.5 bar + Tam Vakum, 120 °C, Ø1400 mm × 2800 mm, SA-240 304 Paslanmaz',
    state: {
      project: {
        projectNo: 'PRJ-VAC-01',
        projectName: 'Vakumlu Proses Tampon Tankı',
        client: 'Standart Şablon',
        revision: 'R0',
        designCode: 'ASME_VIII_DIV_1',
        codeEdition: '2025',
        orientation: 'vertical',
      },
      conditions: {
        operatingPressureMPa: 0.25,
        designPressureMPa: 0.35,
        externalPressureMPa: 0.1013,
        hasVacuum: true,
        operatingTempC: 95,
        designTempC: 120,
        mdmtC: -20,
        corrosionAllowanceIntMm: 0,
        corrosionAllowanceExtMm: 0,
        fluidSpecificGravity: 1.0,
        liquidLevelMm: 2200,
      },
      geometry: {
        materialId: 'sa-240-304',
        insideDiameterMm: 1400,
        shellLengthTanToTanMm: 2800,
        shellNominalThicknessMm: 10,
        jointEfficiencyLong: 0.85,
        jointEfficiencyCirc: 0.85,
        headType: 'ellipsoidal_2_1',
        headNominalThicknessMm: 10,
        headJointEfficiency: 1.0,
        straightFlangeMm: 40,
        nozzles: [
          {
            tag: 'N1',
            service: 'Ürün Besleme (DN150)',
            outsideDiameterMm: 168.3,
            nominalThicknessMm: 7.11,
            externalProjectionMm: 150,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 0,
          },
          {
            tag: 'N2',
            service: 'Vakum Hattı (DN100)',
            outsideDiameterMm: 114.3,
            nominalThicknessMm: 6.02,
            externalProjectionMm: 150,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 0,
          },
        ],
      },
    },
  },
  {
    id: 'vertical-separator',
    title: 'Dikey Seperatör',
    badge: 'EN 13445 · Yüksek Basınç',
    summary: '25 bar, 150 °C, Ø1600 mm × 4000 mm T/T, SA-516 Gr.70, Sıvı Statik Kafa',
    state: {
      project: {
        projectNo: 'PRJ-SEP-01',
        projectName: 'Dikey Gaz-Sıvı Seperatörü',
        client: 'Standart Şablon',
        revision: 'R0',
        designCode: 'EN_13445',
        codeEdition: '2021',
        orientation: 'vertical',
      },
      conditions: {
        operatingPressureMPa: 2.2,
        designPressureMPa: 2.5,
        externalPressureMPa: 0,
        hasVacuum: false,
        operatingTempC: 130,
        designTempC: 150,
        mdmtC: -10,
        corrosionAllowanceIntMm: 3.0,
        corrosionAllowanceExtMm: 0,
        fluidSpecificGravity: 0.85,
        liquidLevelMm: 2000,
      },
      geometry: {
        materialId: 'sa-516-gr70',
        insideDiameterMm: 1600,
        shellLengthTanToTanMm: 4000,
        shellNominalThicknessMm: 20,
        jointEfficiencyLong: 1.0,
        jointEfficiencyCirc: 1.0,
        headType: 'ellipsoidal_2_1',
        headNominalThicknessMm: 18,
        headJointEfficiency: 1.0,
        straightFlangeMm: 50,
        nozzles: [
          {
            tag: 'N1',
            service: 'Karışım Girişi (DN200)',
            outsideDiameterMm: 219.1,
            nominalThicknessMm: 8.18,
            externalProjectionMm: 175,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 3.0,
          },
          {
            tag: 'N2',
            service: 'Gaz Çıkışı (DN150)',
            outsideDiameterMm: 168.3,
            nominalThicknessMm: 7.11,
            externalProjectionMm: 175,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 3.0,
          },
          {
            tag: 'N3',
            service: 'Sıvı Tahliye (DN100)',
            outsideDiameterMm: 114.3,
            nominalThicknessMm: 6.02,
            externalProjectionMm: 150,
            internalProjectionMm: 0,
            jointEfficiency: 1.0,
            corrosionAllowanceMm: 3.0,
          },
        ],
      },
    },
  },
];

/**
 * Seçilen şablonu derin kopya (deep clone) olarak döndürür;
 * form düzenlemelerinin orijinal şablon sabitini bozmasını engeller.
 */
export function clonePresetState(
  presetId: VesselPreset['id'],
  customProjectNo?: string
): VesselProjectState | null {
  const found = VESSEL_PRESETS.find((p) => p.id === presetId);
  if (!found) return null;

  const cloned: VesselProjectState = structuredClone(found.state);
  if (customProjectNo) {
    cloned.project.projectNo = customProjectNo;
  }
  return cloned;
}
