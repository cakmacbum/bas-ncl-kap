/**
 * Vessela — ASME Section VIII Division 1 UG-37 / UG-40 Nozzle Reinforcement Module
 *
 * Implements:
 * - UG-36(c)(3) Small opening exemption check
 * - UG-37(a) Required nozzle neck thickness t_rn
 * - UG-40 Limits of reinforcement (parallel L_par, normal h_limit_out / h_limit_in)
 * - Fig. UG-37.1 Area replacement: A_req vs A_avail = A1 + A2 + A3 + A41 + A42 + A43 + A5
 * - Strength reduction factors fr1, fr2, fr3, fr4 using allowableStress.ts
 */

import {
  getAllowableStress,
  MaterialError,
  MaterialRecord,
  UnitSystem,
} from './allowableStress';

export interface NozzleDesignInput {
  designPressure: number;
  designTemperature: number;
  unitSystem?: UnitSystem;

  /** Vessel shell or head parameters (corroded/nominal) */
  vesselMaterial: MaterialRecord;
  /** Required vessel thickness t_r from UG-27 or UG-32 (excluding CA) */
  vesselRequiredThickness: number;
  /** Nominal vessel thickness t_nom */
  vesselNominalThickness: number;
  /** Vessel internal corrosion allowance */
  vesselCorrosionAllowance: number;
  /** Joint efficiency E1 at opening location (1.0 if not crossing Category A/B weld) */
  vesselJointEfficiencyE1: number;
  /** Correction factor F per Fig. UG-37 (1.0 for radial nozzle on longitudinal plane) */
  correctionFactorF?: number;

  /** Nozzle neck parameters */
  nozzleMaterial: MaterialRecord;
  /** Nominal nozzle outside diameter */
  nozzleOutsideDiameter: number;
  /** Nominal nozzle wall thickness */
  nozzleNominalThickness: number;
  /** Nozzle joint efficiency (1.0 for seamless pipe/forging) */
  nozzleJointEfficiency: number;
  /** Nozzle internal corrosion allowance */
  nozzleCorrosionAllowance: number;
  /** Mill undertolerance on nozzle wall (e.g. 0.125 * t_nom for seamless pipe) */
  nozzleMillUndertolerance?: number;
  /** External nozzle projection above vessel wall (ho) */
  externalProjection: number;
  /** Inward nozzle projection inside vessel wall (hi) */
  internalProjection?: number;

  /** Optional Reinforcement Pad (Repad) */
  repad?: {
    material: MaterialRecord;
    outsideDiameter: number;
    thickness: number;
  };

  /** Optional fillet weld leg sizes (weld 41: nozzle-to-shell/pad, 42: pad-to-shell, 43: inner) */
  weldLegs?: {
    leg41?: number;
    leg42?: number;
    leg43?: number;
  };
}

export interface NozzleCalcOutput {
  codeParagraph: string;
  unitSystem: UnitSystem;
  isExemptPerUg36c3: boolean;
  allowableStressVessel: number;
  allowableStressNozzle: number;
  allowableStressPad?: number;
  corrodedNozzleId: number;
  corrodedNozzleThickness: number;
  corrodedVesselThickness: number;
  requiredNozzleThickness: number;
  limits: {
    parallelLimitLpar: number;
    normalLimitOut: number;
    normalLimitIn: number;
  };
  areas: {
    requiredA: number;
    a1Shell: number;
    a2NozzleOut: number;
    a3NozzleIn: number;
    a41OuterWeld: number;
    a42PadWeld: number;
    a43InnerWeld: number;
    a5Pad: number;
    totalAvailable: number;
    margin: number;
  };
  isReinforcementAdequate: boolean;
  warnings: string[];
}

export type NozzleError =
  | MaterialError
  | {
      code: 'INVALID_INPUT' | 'NOZZLE_THICKNESS_EXCEEDS_LIMIT';
      message: string;
    };

export function calculateUg37Nozzle(
  input: NozzleDesignInput
): { ok: true; data: NozzleCalcOutput } | { ok: false; error: NozzleError } {
  const unitSystem: UnitSystem = input.unitSystem ?? 'SI';
  const warnings: string[] = [];

  if (
    input.designPressure <= 0 ||
    input.nozzleOutsideDiameter <= 0 ||
    input.nozzleNominalThickness <= 0 ||
    input.vesselNominalThickness <= 0 ||
    input.vesselRequiredThickness < 0
  ) {
    return {
      ok: false,
      error: {
        code: 'INVALID_INPUT',
        message: 'Nozzle and vessel dimensions/pressure must be positive.',
      },
    };
  }

  const svRes = getAllowableStress(input.vesselMaterial, input.designTemperature, unitSystem);
  if (!svRes.ok) return svRes;

  const snRes = getAllowableStress(input.nozzleMaterial, input.designTemperature, unitSystem);
  if (!snRes.ok) return snRes;

  const Sv = svRes.data.allowableStress;
  const Sn = snRes.data.allowableStress;
  warnings.push(...svRes.data.warnings, ...snRes.data.warnings);

  let Sp: number | undefined;
  if (input.repad) {
    const spRes = getAllowableStress(input.repad.material, input.designTemperature, unitSystem);
    if (!spRes.ok) return spRes;
    Sp = spRes.data.allowableStress;
    warnings.push(...spRes.data.warnings);
  }

  const P = input.designPressure;
  const F = input.correctionFactorF ?? 1.0;
  const E1 = input.vesselJointEfficiencyE1;

  // Corroded thicknesses and finished opening diameter d
  const t = input.vesselNominalThickness - input.vesselCorrosionAllowance;
  const tn =
    input.nozzleNominalThickness -
    input.nozzleCorrosionAllowance -
    (input.nozzleMillUndertolerance ?? 0);

  if (t <= 0 || tn <= 0) {
    return {
      ok: false,
      error: {
        code: 'INVALID_INPUT',
        message: 'Corroded shell or nozzle wall thickness is <= 0.',
      },
    };
  }

  const d =
    input.nozzleOutsideDiameter -
    2 * (input.nozzleNominalThickness - input.nozzleCorrosionAllowance);
  if (d <= 0) {
    return {
      ok: false,
      error: {
        code: 'INVALID_INPUT',
        message: 'Corroded nozzle inside diameter d <= 0.',
      },
    };
  }

  const Rn = d / 2;
  const denomNozzle = Sn * input.nozzleJointEfficiency - 0.6 * P;
  if (denomNozzle <= 0) {
    return {
      ok: false,
      error: {
        code: 'NOZZLE_THICKNESS_EXCEEDS_LIMIT',
        message: 'Design pressure exceeds nozzle neck allowable stress limit.',
      },
    };
  }

  // UG-37(a) required nozzle thickness
  const trn = (P * Rn) / denomNozzle;
  if (tn < trn) {
    warnings.push(
      `Corroded nozzle wall (${tn.toFixed(2)}) is thinner than UG-37(a) required t_rn (${trn.toFixed(2)}).`
    );
  }

  // UG-36(c)(3) Small opening exemption check (single isolated opening)
  const smallLimitThick = unitSystem === 'SI' ? 10 : 0.375;
  const smallLimitLarge = unitSystem === 'SI' ? 89 : 3.5;
  const smallLimitSmall = unitSystem === 'SI' ? 60 : 2.375;
  const isExemptPerUg36c3 =
    t <= smallLimitThick ? d <= smallLimitLarge : d <= smallLimitSmall;

  // Strength reduction factors
  const fr1 = Math.min(1.0, Sn / Sv);
  const fr2 = Math.min(1.0, Sn / Sv);
  const fr3 = Math.min(1.0, Math.min(Sn, Sv) / Sv);
  const fr4 = Sp !== undefined ? Math.min(1.0, Sp / Sv) : 1.0;

  // UG-40 Limits of reinforcement
  const te = input.repad ? input.repad.thickness : 0;
  const Lpar = Math.max(d, Rn + t + tn);
  const hLimitOut = Math.min(2.5 * t, 2.5 * tn + te);
  const hLimitIn = Math.min(2.5 * t, 2.5 * tn);

  // Required reinforcement area A (Fig. UG-37.1)
  const tr = input.vesselRequiredThickness;
  const requiredA = Math.max(0, d * tr * F + 2 * tn * tr * F * (1 - fr1));

  // Available areas
  const a1Shell = Math.max(
    0,
    (2 * Lpar - d) * (E1 * t - F * tr) - 2 * tn * (E1 * t - F * tr) * (1 - fr1)
  );

  const effNozzleThickOut = Math.max(0, Math.min(tn, Lpar - 0.5 * d) - trn);
  const a2NozzleOut = Math.max(
    0,
    2 * Math.min(input.externalProjection, hLimitOut) * effNozzleThickOut * fr2
  );

  const hi = input.internalProjection ?? 0;
  const effNozzleThickIn = Math.min(tn, Lpar - 0.5 * d);
  const a3NozzleIn = Math.max(0, 2 * Math.min(hi, hLimitIn) * effNozzleThickIn * fr2);

  const leg41 = input.weldLegs?.leg41 ?? 0;
  const leg42 = input.weldLegs?.leg42 ?? 0;
  const leg43 = input.weldLegs?.leg43 ?? 0;

  const a41OuterWeld = Math.pow(leg41, 2) * fr3;
  const a42PadWeld = input.repad ? Math.pow(leg42, 2) * fr4 : 0;
  const a43InnerWeld = Math.pow(leg43, 2) * fr2;

  let a5Pad = 0;
  if (input.repad) {
    const effPadOd = Math.min(input.repad.outsideDiameter, 2 * Lpar);
    if (input.repad.outsideDiameter > 2 * Lpar) {
      warnings.push(
        `Repad OD (${input.repad.outsideDiameter}) exceeds UG-40 limit 2*L_par (${(2 * Lpar).toFixed(2)}); excess width excluded.`
      );
    }
    const padWidth = Math.max(0, effPadOd - d - 2 * tn);
    a5Pad = padWidth * input.repad.thickness * fr4;
  }

  const totalAvailable =
    a1Shell + a2NozzleOut + a3NozzleIn + a41OuterWeld + a42PadWeld + a43InnerWeld + a5Pad;
  const margin = totalAvailable - requiredA;
  const isReinforcementAdequate = isExemptPerUg36c3 || (margin >= 0 && tn >= trn);

  return {
    ok: true,
    data: {
      codeParagraph: 'UG-37 / UG-40',
      unitSystem,
      isExemptPerUg36c3,
      allowableStressVessel: Sv,
      allowableStressNozzle: Sn,
      allowableStressPad: Sp,
      corrodedNozzleId: Number(d.toFixed(3)),
      corrodedNozzleThickness: Number(tn.toFixed(3)),
      corrodedVesselThickness: Number(t.toFixed(3)),
      requiredNozzleThickness: Number(trn.toFixed(3)),
      limits: {
        parallelLimitLpar: Number(Lpar.toFixed(3)),
        normalLimitOut: Number(hLimitOut.toFixed(3)),
        normalLimitIn: Number(hLimitIn.toFixed(3)),
      },
      areas: {
        requiredA: Number(requiredA.toFixed(3)),
        a1Shell: Number(a1Shell.toFixed(3)),
        a2NozzleOut: Number(a2NozzleOut.toFixed(3)),
        a3NozzleIn: Number(a3NozzleIn.toFixed(3)),
        a41OuterWeld: Number(a41OuterWeld.toFixed(3)),
        a42PadWeld: Number(a42PadWeld.toFixed(3)),
        a43InnerWeld: Number(a43InnerWeld.toFixed(3)),
        a5Pad: Number(a5Pad.toFixed(3)),
        totalAvailable: Number(totalAvailable.toFixed(3)),
        margin: Number(margin.toFixed(3)),
      },
      isReinforcementAdequate,
      warnings,
    },
  };
}
