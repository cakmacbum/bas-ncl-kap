/**
 * Vessela — StepErrorBoundary & Güvenli State Yönetimi Örneği
 *
 * 03-06 adımlarındaki beyaz ekran (White Screen of Death) çökmesini çözmek için:
 * 1. Her adımı saran ve aktif adım değiştiğinde kendini sıfırlayan StepErrorBoundary
 * 2. Başlangıçta null/undefined bırakmayan, preset ile hydrate edilen güvenli state
 * 3. Hesaplama sonucu yokken 04/05/06 ekranlarının çökmesini engelleyen Guard bileşeni
 */

import React, { Component, ErrorInfo, ReactNode, useMemo, useState } from 'react';
import { VESSEL_PRESETS, VesselProjectState, clonePresetState } from './vesselPresets';
import materialsData from './materials.sample.json';
import { MaterialRecord } from './allowableStress';
import { calculateUg27Shell, ShellCalcOutput } from './ug27Shell';
import { calculateUg32Head, HeadCalcOutput } from './ug32Head';

// ---------------------------------------------------------------------------
// 1. React ErrorBoundary (activeStep değişince resetKeys ile otomatik sıfırlanır)
// ---------------------------------------------------------------------------

interface ErrorBoundaryProps {
  stepId: string;
  onReturnSafeStep?: () => void;
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class StepErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Beklenmeyen bir render hatası oluştu.',
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Geliştirme ve telemetry için gerçek hatayı yakala
    console.error(`[Vessela Step ${this.props.stepId} Crash]:`, error, info.componentStack);
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps) {
    // Kullanıcı başka bir adıma geçerse hata durumunu temizle
    if (prevProps.stepId !== this.props.stepId && this.state.hasError) {
      this.setState({ hasError: false, errorMessage: '' });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="rounded-lg border border-red-500/40 bg-red-950/30 p-6 text-slate-100">
          <h3 className="text-base font-semibold text-red-300">
            Adım {this.props.stepId} yüklenirken bir hata oluştu
          </h3>
          <p className="mt-2 text-sm text-slate-300">
            Hata detayı: <code className="text-red-200">{this.state.errorMessage}</code>
          </p>
          <div className="mt-4 flex gap-3">
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, errorMessage: '' })}
              className="rounded bg-slate-700 px-3 py-1.5 text-sm hover:bg-slate-600"
            >
              Tekrar Dene
            </button>
            {this.props.onReturnSafeStep && (
              <button
                type="button"
                onClick={this.props.onReturnSafeStep}
                className="rounded bg-teal-600 px-3 py-1.5 text-sm font-medium hover:bg-teal-500"
              >
                01 Yeni Proje Adımına Dön
              </button>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// ---------------------------------------------------------------------------
// 2. Güvenli State & Hesaplama Hook'u (Null/Undefined Korumalı)
// ---------------------------------------------------------------------------

export interface VesselCalculationBundle {
  shell: ShellCalcOutput | null;
  head: HeadCalcOutput | null;
  errors: string[];
  calculatedAt: string | null;
}

const DEFAULT_STATE: VesselProjectState =
  clonePresetState('horizontal-air-receiver') ?? VESSEL_PRESETS[0].state;

export function useVesselaWorkspace() {
  const [activeStep, setActiveStep] = useState<'01' | '02' | '03' | '04' | '05' | '06'>('01');
  const [vesselState, setVesselState] = useState<VesselProjectState>(DEFAULT_STATE);
  const [calcBundle, setCalcBundle] = useState<VesselCalculationBundle>({
    shell: null,
    head: null,
    errors: [],
    calculatedAt: null,
  });

  const materials = useMemo(
    () => (materialsData.materials as MaterialRecord[]) ?? [],
    []
  );

  const runCalculation = () => {
    const mat = materials.find((m) => m.id === vesselState.geometry.materialId);
    if (!mat) {
      setCalcBundle({
        shell: null,
        head: null,
        errors: [`Seçili malzeme bulunamadı: ${vesselState.geometry.materialId}`],
        calculatedAt: null,
      });
      return;
    }

    const errors: string[] = [];
    const shellRes = calculateUg27Shell({
      geometry: 'cylindrical',
      insideDiameter: vesselState.geometry.insideDiameterMm,
      designPressure: vesselState.conditions.designPressureMPa,
      designTemperature: vesselState.conditions.designTempC,
      material: mat,
      jointEfficiencyLong: vesselState.geometry.jointEfficiencyLong,
      jointEfficiencyCirc: vesselState.geometry.jointEfficiencyCirc,
      corrosionAllowance: vesselState.conditions.corrosionAllowanceIntMm,
      nominalThickness: vesselState.geometry.shellNominalThicknessMm,
      unitSystem: 'SI',
    });

    const headRes = calculateUg32Head({
      headType: vesselState.geometry.headType,
      insideDiameter: vesselState.geometry.insideDiameterMm,
      designPressure: vesselState.conditions.designPressureMPa,
      designTemperature: vesselState.conditions.designTempC,
      material: mat,
      jointEfficiency: vesselState.geometry.headJointEfficiency,
      corrosionAllowance: vesselState.conditions.corrosionAllowanceIntMm,
      nominalThickness: vesselState.geometry.headNominalThicknessMm,
      unitSystem: 'SI',
    });

    if (!shellRes.ok) errors.push(`Gövde: ${shellRes.error.message}`);
    if (!headRes.ok) errors.push(`Bombe: ${headRes.error.message}`);

    setCalcBundle({
      shell: shellRes.ok ? shellRes.data : null,
      head: headRes.ok ? headRes.data : null,
      errors,
      calculatedAt: new Date().toISOString(),
    });
  };

  return {
    activeStep,
    setActiveStep,
    vesselState,
    setVesselState,
    calcBundle,
    runCalculation,
  };
}

// ---------------------------------------------------------------------------
// 3. Adım 04 / 05 / 06 için Eksik Veri Koruması (Beyaz Ekran Yerine Yönlendirme)
// ---------------------------------------------------------------------------

interface SafeResultGuardProps {
  calcBundle: VesselCalculationBundle;
  onRunCalculation: () => void;
  children: (ready: { shell: ShellCalcOutput; head: HeadCalcOutput }) => ReactNode;
}

export function SafeResultGuard({
  calcBundle,
  onRunCalculation,
  children,
}: SafeResultGuardProps) {
  if (!calcBundle.shell || !calcBundle.head) {
    return (
      <div className="rounded-lg border border-slate-700 bg-slate-900/70 p-6 text-slate-200">
        <p className="text-sm">
          Sonuçları ve 3D/rapor çıktılarını görüntülemek için önce hesaplamayı çalıştırın.
        </p>
        {calcBundle.errors.length > 0 && (
          <ul className="mt-2 list-disc pl-5 text-xs text-amber-300">
            {calcBundle.errors.map((err, idx) => (
              <li key={idx}>{err}</li>
            ))}
          </ul>
        )}
        <button
          type="button"
          onClick={onRunCalculation}
          className="mt-4 rounded bg-teal-600 px-4 py-2 text-sm font-medium text-white hover:bg-teal-500"
        >
          Hesapla
        </button>
      </div>
    );
  }

  return <>{children({ shell: calcBundle.shell, head: calcBundle.head })}</>;
}
