/**
 * Vessela — ASME Section VIII Division 1 UG-32 Formed Head Thickness & MAWP Module
 *
 * Implements:
 * - UG-32(d) 2:1 Ellipsoidal heads (h = D/4)
 * - UG-32(e) Standard Torispherical (F&D) heads (L = Do or Di, r = 0.06*L -> L/r = 16.67)
 * - UG-32(f) Hemispherical heads
 * - Corroded dimensions: D_c = D + 2*CA, L_c = L + CA, t_c = t_nom - CA - formingAllowance
 */

import {
  getAllowableStress,
  MaterialError,
  MaterialRecord,
  UnitSystem,
} from './allowableStress';

export type HeadType = 'ellipsoidal_2_1' | 'torispherical_fd' | 'hemispherical';

export interface HeadDesignInput {
  headType: HeadType;
  /** Nominal inside diameter (mm for SI, in for US) */
  insideDiameter: number;
  /** Inside crown radius L for torispherical or hemispherical heads (defaults to ID for F&D, ID/2 for hemi) */
  insideCrownRadius?: number;
  /** Internal design pressure (MPa for SI, psi for US) */
  designPressure: number;
  /** Design temperature (°C for SI, °F for US) */
  designTemperature: number;
  material: MaterialRecord;
  /** Joint efficiency E (1.0 for seamless head meeting UW-11(a)(5)(b), 0.85 otherwise, or UW-12) */
  jointEfficiency: number;
  /** Internal corrosion allowance (mm for SI, in for US) */
  corrosionAllowance: number;
  /** Optional nominal/selected head blank thickness after forming */
  nominalThickness?: number;
  /** Forming thinning / mill undertolerance (mm or in) */
  formingAllowance?: number;
  unitSystem?: UnitSystem;
}

export interface HeadCalcOutput {
  codeParagraph: string;
  headType: HeadType;
  unitSystem: UnitSystem;
  allowableStress: number;
  corrodedInsideDiameter: number;
  corrodedCrownRadius?: number;
  /** Minimum required corroded thickness (excluding CA) */
  requiredThickness: number;
  /** Required nominal thickness including CA and forming allowance */
  requiredNominalThickness: number;
  mawp?: number;
  corrodedThickness?: number;
  isCodeCompliant: boolean;
  warnings: string[];
}

export type HeadError =
  | MaterialError
  | {
      code: 'INVALID_INPUT' | 'APPLICABILITY_LIMIT_EXCEEDED';
      message: string;
    };

export function calculateUg32Head(
  input: HeadDesignInput
): { ok: true; data: HeadCalcOutput } | { ok: false; error: HeadError } {
  const unitSystem: UnitSystem = input.unitSystem ?? 'SI';
  const warnings: string[] = [];

  if (
    input.insideDiameter <= 0 ||
    input.designPressure <= 0 ||
    input.corrosionAllowance < 0 ||
    input.jointEfficiency <= 0 ||
    input.jointEfficiency > 1
  ) {
    return {
      ok: false,
      error: {
        code: 'INVALID_INPUT',
        message:
          'Head inputs out of range: ID > 0, P > 0, CA >= 0, and 0 < E <= 1.0 are required.',
      },
    };
  }

  const stressRes = getAllowableStress(
    input.material,
    input.designTemperature,
    unitSystem
  );
  if (!stressRes.ok) {
    return stressRes;
  }

  const S = stressRes.data.allowableStress;
  warnings.push(...stressRes.data.warnings);

  const P = input.designPressure;
  const E = input.jointEfficiency;
  const Dc = input.insideDiameter + 2 * input.corrosionAllowance;
  const forming = input.formingAllowance ?? 0;
  const minUg16 = unitSystem === 'SI' ? 1.5 : 0.0625;

  let codeParagraph = '';
  let tReq = 0;
  let Lc: number | undefined;

  if (input.headType === 'ellipsoidal_2_1') {
    codeParagraph = 'UG-32(d)';
    if (2 * S * E - 0.2 * P <= 0) {
      return {
        ok: false,
        error: {
          code: 'APPLICABILITY_LIMIT_EXCEEDED',
          message: 'Design pressure exceeds 2:1 ellipsoidal head limit (2SE - 0.2P <= 0).',
        },
      };
    }
    tReq = (P * Dc) / (2 * S * E - 0.2 * P);
  } else if (input.headType === 'torispherical_fd') {
    codeParagraph = 'UG-32(e)';
    const Lnom = input.insideCrownRadius ?? input.insideDiameter;
    Lc = Lnom + input.corrosionAllowance;

    if (S * E - 0.1 * P <= 0) {
      return {
        ok: false,
        error: {
          code: 'APPLICABILITY_LIMIT_EXCEEDED',
          message: 'Design pressure exceeds torispherical head limit (SE - 0.1P <= 0).',
        },
      };
    }
    tReq = (0.885 * P * Lc) / (S * E - 0.1 * P);

    if (tReq / Lc < 0.002) {
      warnings.push(
        `t/L ratio (${(tReq / Lc).toFixed(5)}) is below 0.002; check ASME VIII-1 Appendix 1-4(f) buckling rules.`
      );
    }
  } else {
    codeParagraph = 'UG-32(f)';
    const Lnom = input.insideCrownRadius ?? input.insideDiameter / 2;
    Lc = Lnom + input.corrosionAllowance;

    if (P > 0.665 * S * E) {
      return {
        ok: false,
        error: {
          code: 'APPLICABILITY_LIMIT_EXCEEDED',
          message: `P (${P}) exceeds 0.665*S*E (${(0.665 * S * E).toFixed(3)}). Appendix 1-3 thick-wall rules apply.`,
        },
      };
    }
    tReq = (P * Lc) / (2 * S * E - 0.2 * P);

    if (tReq > 0.356 * Lc) {
      return {
        ok: false,
        error: {
          code: 'APPLICABILITY_LIMIT_EXCEEDED',
          message: `Required thickness (${tReq.toFixed(3)}) exceeds 0.356*L (${(0.356 * Lc).toFixed(3)}). Appendix 1-3 thick-wall rules apply.`,
        },
      };
    }
  }

  if (tReq < minUg16) {
    warnings.push(
      `Calculated thickness (${tReq.toFixed(2)}) is below UG-16(b) minimum (${minUg16}).`
    );
  }

  const tNomReq = tReq + input.corrosionAllowance + forming;
  let mawp: number | undefined;
  let tc: number | undefined;
  let isCodeCompliant = true;

  if (input.nominalThickness !== undefined) {
    tc = input.nominalThickness - input.corrosionAllowance - forming;
    if (tc <= 0) {
      isCodeCompliant = false;
      warnings.push('Nominal thickness does not cover corrosion allowance and forming thinning.');
    } else {
      if (input.headType === 'ellipsoidal_2_1') {
        mawp = (2 * S * E * tc) / (Dc + 0.2 * tc);
      } else if (input.headType === 'torispherical_fd' && Lc !== undefined) {
        mawp = (S * E * tc) / (0.885 * Lc + 0.1 * tc);
      } else if (Lc !== undefined) {
        mawp = (2 * S * E * tc) / (Lc + 0.2 * tc);
      }
      if (tc < tReq) isCodeCompliant = false;
    }
  }

  return {
    ok: true,
    data: {
      codeParagraph,
      headType: input.headType,
      unitSystem,
      allowableStress: S,
      corrodedInsideDiameter: Number(Dc.toFixed(3)),
      corrodedCrownRadius: Lc !== undefined ? Number(Lc.toFixed(3)) : undefined,
      requiredThickness: Number(tReq.toFixed(3)),
      requiredNominalThickness: Number(tNomReq.toFixed(3)),
      mawp: mawp !== undefined ? Number(mawp.toFixed(4)) : undefined,
      corrodedThickness: tc !== undefined ? Number(tc.toFixed(3)) : undefined,
      isCodeCompliant,
      warnings,
    },
  };
}
