/**
 * Vessela — ASME Section VIII Division 1 UG-27 Shell Thickness & MAWP Module
 *
 * Implements:
 * - UG-27(c)(1) Cylindrical shell: Circumferential stress (longitudinal joints)
 * - UG-27(c)(2) Cylindrical shell: Longitudinal stress (circumferential joints)
 * - UG-27(d)    Spherical shell
 * - Corroded inside radius R_c = ID/2 + CA and corroded wall t_c = t_nom - CA - millUndertolerance
 * - Code applicability limits (t <= 0.5R, P <= 0.385*S*E, etc.)
 * - UG-16(b) 1.5 mm minimum thickness warning
 */

import {
  CalcResult,
  getAllowableStress,
  MaterialError,
  MaterialRecord,
  UnitSystem,
} from './allowableStress';

export type ShellGeometryType = 'cylindrical' | 'spherical';

export interface ShellDesignInput {
  geometry: ShellGeometryType;
  /** Nominal inside diameter (mm for SI, in for US) */
  insideDiameter: number;
  /** Internal design pressure (MPa for SI, psi for US) */
  designPressure: number;
  /** Design temperature (°C for SI, °F for US) */
  designTemperature: number;
  /** Material record from ASME Section II Part D database */
  material: MaterialRecord;
  /** Longitudinal joint efficiency E_L (Table UW-12, 0.45–1.0) */
  jointEfficiencyLong: number;
  /** Circumferential joint efficiency E_C (Table UW-12, 0.45–1.0) */
  jointEfficiencyCirc: number;
  /** Internal corrosion allowance (mm for SI, in for US) */
  corrosionAllowance: number;
  /** Optional nominal/selected plate thickness to evaluate MAWP */
  nominalThickness?: number;
  /** Mill undertolerance (mm or in, e.g. 0.3 mm for plate or 12.5% for seamless pipe) */
  millUndertolerance?: number;
  unitSystem?: UnitSystem;
}

export interface ShellCalcOutput {
  codeParagraph: string;
  unitSystem: UnitSystem;
  allowableStress: number;
  corrodedInsideRadius: number;
  /** Minimum required corroded thickness (excluding CA) */
  requiredThicknessCirc: number;
  requiredThicknessLong?: number;
  governingRequiredThickness: number;
  /** Required nominal thickness including corrosion allowance */
  requiredNominalThickness: number;
  /** Calculated MAWP (corroded) if nominalThickness is provided */
  mawp?: number;
  corrodedThickness?: number;
  isCodeCompliant: boolean;
  warnings: string[];
}

export type ShellError =
  | MaterialError
  | {
      code:
        | 'INVALID_INPUT'
        | 'PRESSURE_EXCEEDS_THIN_WALL_LIMIT'
        | 'THICKNESS_EXCEEDS_THIN_WALL_LIMIT';
      message: string;
    };

export function calculateUg27Shell(
  input: ShellDesignInput
): { ok: true; data: ShellCalcOutput } | { ok: false; error: ShellError } {
  const unitSystem: UnitSystem = input.unitSystem ?? 'SI';
  const warnings: string[] = [];

  if (
    input.insideDiameter <= 0 ||
    input.designPressure <= 0 ||
    input.corrosionAllowance < 0 ||
    input.jointEfficiencyLong <= 0 ||
    input.jointEfficiencyLong > 1 ||
    input.jointEfficiencyCirc <= 0 ||
    input.jointEfficiencyCirc > 1
  ) {
    return {
      ok: false,
      error: {
        code: 'INVALID_INPUT',
        message:
          'Shell inputs out of range: ID > 0, P > 0, CA >= 0, and 0 < E <= 1.0 are required.',
      },
    };
  }

  const stressRes: CalcResult<ReturnType<typeof getAllowableStress> extends CalcResult<infer U> ? U : never> =
    getAllowableStress(input.material, input.designTemperature, unitSystem);
  if (!stressRes.ok) {
    return stressRes;
  }

  const S = stressRes.data.allowableStress;
  warnings.push(...stressRes.data.warnings);

  const P = input.designPressure;
  const Rc = input.insideDiameter / 2 + input.corrosionAllowance;
  const minUg16 = unitSystem === 'SI' ? 1.5 : 0.0625;

  if (input.geometry === 'spherical') {
    const E = input.jointEfficiencyLong;
    if (P > 0.665 * S * E) {
      return {
        ok: false,
        error: {
          code: 'PRESSURE_EXCEEDS_THIN_WALL_LIMIT',
          message: `P (${P}) exceeds 0.665*S*E (${(0.665 * S * E).toFixed(3)}). Use ASME VIII-1 Appendix 1-3 thick-wall rules.`,
        },
      };
    }

    const tReq = (P * Rc) / (2 * S * E - 0.2 * P);
    if (tReq > 0.356 * Rc) {
      return {
        ok: false,
        error: {
          code: 'THICKNESS_EXCEEDS_THIN_WALL_LIMIT',
          message: `Required thickness (${tReq.toFixed(3)}) exceeds 0.356*R (${(0.356 * Rc).toFixed(3)}). Appendix 1-3 thick-wall rules apply.`,
        },
      };
    }

    if (tReq < minUg16) {
      warnings.push(
        `Calculated thickness (${tReq.toFixed(2)}) is below UG-16(b) minimum (${minUg16}).`
      );
    }

    const tNomReq = tReq + input.corrosionAllowance + (input.millUndertolerance ?? 0);
    let mawp: number | undefined;
    let tc: number | undefined;
    let isCodeCompliant = true;

    if (input.nominalThickness !== undefined) {
      tc = input.nominalThickness - input.corrosionAllowance - (input.millUndertolerance ?? 0);
      if (tc <= 0) {
        isCodeCompliant = false;
        warnings.push('Nominal thickness does not cover corrosion allowance and mill undertolerance.');
      } else {
        mawp = (2 * S * E * tc) / (Rc + 0.2 * tc);
        if (tc < tReq) isCodeCompliant = false;
      }
    }

    return {
      ok: true,
      data: {
        codeParagraph: 'UG-27(d)',
        unitSystem,
        allowableStress: S,
        corrodedInsideRadius: Number(Rc.toFixed(3)),
        requiredThicknessCirc: Number(tReq.toFixed(3)),
        governingRequiredThickness: Number(tReq.toFixed(3)),
        requiredNominalThickness: Number(tNomReq.toFixed(3)),
        mawp: mawp !== undefined ? Number(mawp.toFixed(4)) : undefined,
        corrodedThickness: tc !== undefined ? Number(tc.toFixed(3)) : undefined,
        isCodeCompliant,
        warnings,
      },
    };
  }

  // Cylindrical shell: UG-27(c)(1) & UG-27(c)(2)
  const EL = input.jointEfficiencyLong;
  const EC = input.jointEfficiencyCirc;

  if (P > 0.385 * S * EL) {
    return {
      ok: false,
      error: {
        code: 'PRESSURE_EXCEEDS_THIN_WALL_LIMIT',
        message: `P (${P}) exceeds 0.385*S*E_L (${(0.385 * S * EL).toFixed(3)}). Use ASME VIII-1 Appendix 1-2 thick-wall rules.`,
      },
    };
  }

  const tCirc = (P * Rc) / (S * EL - 0.6 * P);
  const tLong = (P * Rc) / (2 * S * EC + 0.4 * P);
  const tGov = Math.max(tCirc, tLong);

  if (tGov > 0.5 * Rc) {
    return {
      ok: false,
      error: {
        code: 'THICKNESS_EXCEEDS_THIN_WALL_LIMIT',
        message: `Required thickness (${tGov.toFixed(3)}) exceeds 0.5*R (${(0.5 * Rc).toFixed(3)}). Appendix 1-2 thick-wall rules apply.`,
      },
    };
  }

  if (tGov < minUg16) {
    warnings.push(
      `Calculated thickness (${tGov.toFixed(2)}) is below UG-16(b) minimum (${minUg16}).`
    );
  }

  const tNomReq = tGov + input.corrosionAllowance + (input.millUndertolerance ?? 0);
  let mawp: number | undefined;
  let tc: number | undefined;
  let isCodeCompliant = true;

  if (input.nominalThickness !== undefined) {
    tc = input.nominalThickness - input.corrosionAllowance - (input.millUndertolerance ?? 0);
    if (tc <= 0) {
      isCodeCompliant = false;
      warnings.push('Nominal thickness does not cover corrosion allowance and mill undertolerance.');
    } else {
      const mawpCirc = (S * EL * tc) / (Rc + 0.6 * tc);
      const mawpLong = (2 * S * EC * tc) / (Rc - 0.4 * tc);
      mawp = Math.min(mawpCirc, mawpLong);
      if (tc < tGov) isCodeCompliant = false;
    }
  }

  return {
    ok: true,
    data: {
      codeParagraph: tCirc >= tLong ? 'UG-27(c)(1)' : 'UG-27(c)(2)',
      unitSystem,
      allowableStress: S,
      corrodedInsideRadius: Number(Rc.toFixed(3)),
      requiredThicknessCirc: Number(tCirc.toFixed(3)),
      requiredThicknessLong: Number(tLong.toFixed(3)),
      governingRequiredThickness: Number(tGov.toFixed(3)),
      requiredNominalThickness: Number(tNomReq.toFixed(3)),
      mawp: mawp !== undefined ? Number(mawp.toFixed(4)) : undefined,
      corrodedThickness: tc !== undefined ? Number(tc.toFixed(3)) : undefined,
      isCodeCompliant,
      warnings,
    },
  };
}
