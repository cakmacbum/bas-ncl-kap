# Vessela — ASME VIII-1 Çekirdek Hesaplama & Hata Düzeltme Paketi

Bu paket, `https://app.zeyslabs-vessela.com/` canlı incelemesinde tespit edilen kritik hataları çözmek ve **PV Elite** / **Codeware COMPRESS** seviyesine giden açık kaynak ASME Section VIII Division 1 hesaplama çekirdeğini kurmak için hazırlanmıştır.

## 1. Canlı İncelemede Tespit Edilen Hatalar ve Eksikler

1. **Adım 03–06 Beyaz Ekran Çökmesi:** `03 Kap Geometrisi`, `04 Hesap Sonuçları`, `05 3D Model` ve `06 Rapor & Çıktı` ekranlarına geçildiğinde istemci tarafında yakalanmayan JS hatası nedeniyle uygulama beyaza düşmektedir.
2. **Etkisiz UI Kontrolleri:** `Projeleri Yenile` ve `Henüz hesaplanmadı` alanları aksiyon tetiklememektedir.
3. **Eksik Girdi Doğrulamaları & Malzeme Katmanı:** Negatif/geçersiz sayısal değerler engellenmemekte; önizlemede `SA-516 Gr.70` görünmesine rağmen malzeme kütüphanesi, izin verilen gerilme ($S$) ve kaynak verimliliği ($E$) seçimi bulunmamaktadır.
4. **PV Elite / COMPRESS Kıyasındaki Ana Eksikler:** ASME VIII Div 2, Imperial birim desteği, WRC-107/537 lokal nozul yükleri, Zick semer analizi, UCS-66 MDMT eğrileri, B16.5 flanş P-T kontrolü ve U-1/U-1A veri raporu dışa aktarımı.

## 2. Paket İçeriği

| Dosya | Açıklama |
| :--- | :--- |
| `asme-material-schema.json` | ASME Section II Part D malzemeleri için Draft 2020-12 JSON Schema (Table 1A/1B, UCS-66 eğrisi, dış basınç grafiği, yoğunluk). |
| `materials.sample.json` | `SA-516 Gr.70`, `SA-240 Type 304` ve `SA-240 Type 316L` için örnek malzeme veri seti (üretim öncesinde lisanslı ASME II-D Table 1A-M ara değerleri eklenmelidir). |
| `allowableStress.ts` | Sıcaklığa bağlı doğrusal $S$ interpolasyonu, üst sınır ekstrapolasyon engeli ve UG-99 hidrostatik test gerilme oranı (`getHydrotestStressRatio`) modülü. |
| `ug27Shell.ts` | ASME VIII-1 UG-27(c)(1)/(2) silindirik ve UG-27(d) küresel gövde et kalınlığı, korozyonlu MAWP ve ince cidar sınır kontrolü. |
| `ug32Head.ts` | ASME VIII-1 UG-32(d) 2:1 elipsoidal, UG-32(e) torisferik (F&D) ve UG-32(f) yarımküre bombe et kalınlığı ve MAWP modülü. |
| `ug37Nozzle.ts` | ASME VIII-1 UG-36(c)(3) küçük delik muafiyeti, UG-37(a) nozul boyun kalınlığı, UG-40 takviye sınırları ve $A_1 \dots A_5$ alan dengesi. |
| `vesselaCalc.test.ts` | Tüm hesaplama modüllerini örnek ASME problemleriyle doğrulayan Vitest test seti. |
| `vesselPresets.ts` | `01 Yeni Proje` ekranı için *Yatay Hava Tankı*, *Vakumlu Proses Tankı* ve *Dikey Seperatör* başlangıç şablonları. |
| `StepErrorBoundaryAndStore.tsx` | `03–06` adımlarındaki beyaz ekran çökmesini önleyen `StepErrorBoundary`, `useVesselaWorkspace` hook'u ve `SafeResultGuard` bileşeni. |

## 3. Hızlı Başlangıç ve Test

```bash
# Projeye TypeScript dosyalarını kopyaladıktan sonra testleri çalıştırın:
npx vitest run vesselaCalc.test.ts
```
