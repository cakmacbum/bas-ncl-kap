/**
 * Vessela — Vitest Verification Suite for ASME Section II-D & VIII-1 Modules
 *
 * Covers:
 * - allowableStress.ts: linear interpolation, ambient clamping, extrapolation guard, UG-99 LSR
 * - ug27Shell.ts: UG-27(c)(1)/(2) cylindrical shell, corroded radius, MAWP, thin-wall limit
 * - ug32Head.ts: UG-32(d) 2:1 ellipsoidal, UG-32(e) torispherical, UG-32(f) hemispherical
 * - ug37Nozzle.ts: UG-36(c)(3) exemption, UG-37/UG-40 area replacement with/without repad
 */

import { describe, expect, it } from 'vitest';
import materialsData from './materials.sample.json';
import {
  getAllowableStress,
  getHydrotestStressRatio,
  MaterialRecord,
} from './allowableStress';
import { calculateUg27Shell } from './ug27Shell';
import { calculateUg32Head } from './ug32Head';
import { calculateUg37Nozzle } from './ug37Nozzle';

const materials = materialsData.materials as MaterialRecord[];
const sa516Gr70 = materials.find((m) => m.id === 'sa-516-gr70')!;

describe('allowableStress — ASME Section II Part D', () => {
  it('returns exact breakpoint value for SA-516 Gr.70 at 200 °C', () => {
    const res = getAllowableStress(sa516Gr70, 200, 'SI');
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.allowableStress).toBe(138.0);
      expect(res.data.isExactBreakpoint).toBe(true);
    }
  });

  it('linearly interpolates S between 200 °C (138 MPa) and 300 °C (128 MPa) at 250 °C', () => {
    const res = getAllowableStress(sa516Gr70, 250, 'SI');
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.allowableStress).toBeCloseTo(133.0, 3);
      expect(res.data.isExactBreakpoint).toBe(false);
    }
  });

  it('clamps ambient stress below 40 °C down to minTempC with MDMT warning', () => {
    const res = getAllowableStress(sa516Gr70, 20, 'SI');
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.allowableStress).toBe(138.0);
      expect(res.data.warnings.length).toBeGreaterThan(0);
    }
  });

  it('rejects extrapolation above highest tabulated temperature', () => {
    const res = getAllowableStress(sa516Gr70, 400, 'SI');
    expect(res.ok).toBe(false);
    if (!res.ok) {
      expect(res.error.code).toBe('TEMPERATURE_EXCEEDS_MAX');
    }
  });

  it('computes UG-99 hydrotest stress ratio (S_test / S_design)', () => {
    const res = getHydrotestStressRatio(sa516Gr70, 300, 25, 'SI');
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.sDesign).toBe(128.0);
      expect(res.data.sTest).toBe(138.0);
      expect(res.data.lsr).toBeCloseTo(1.0781, 4);
    }
  });
});

describe('ug27Shell — ASME VIII-1 UG-27', () => {
  it('matches worked cylindrical shell example (ID=1800 mm, P=2.5 MPa, S=138 MPa, E=1.0, CA=0)', () => {
    const res = calculateUg27Shell({
      geometry: 'cylindrical',
      insideDiameter: 1800,
      designPressure: 2.5,
      designTemperature: 200,
      material: sa516Gr70,
      jointEfficiencyLong: 1.0,
      jointEfficiencyCirc: 0.85,
      corrosionAllowance: 0,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.codeParagraph).toBe('UG-27(c)(1)');
      expect(res.data.requiredThicknessCirc).toBeCloseTo(16.484, 2);
      expect(res.data.governingRequiredThickness).toBeCloseTo(16.484, 2);
    }
  });

  it('applies corroded inside radius (R_c = ID/2 + CA) and evaluates MAWP', () => {
    const res = calculateUg27Shell({
      geometry: 'cylindrical',
      insideDiameter: 1800,
      designPressure: 2.5,
      designTemperature: 200,
      material: sa516Gr70,
      jointEfficiencyLong: 1.0,
      jointEfficiencyCirc: 1.0,
      corrosionAllowance: 3,
      nominalThickness: 22,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.corrodedInsideRadius).toBe(903);
      expect(res.data.corrodedThickness).toBe(19);
      expect(res.data.isCodeCompliant).toBe(true);
      expect(res.data.mawp).toBeGreaterThan(2.5);
    }
  });

  it('rejects pressure exceeding 0.385*S*E thin-wall limit', () => {
    const res = calculateUg27Shell({
      geometry: 'cylindrical',
      insideDiameter: 1000,
      designPressure: 60,
      designTemperature: 200,
      material: sa516Gr70,
      jointEfficiencyLong: 1.0,
      jointEfficiencyCirc: 1.0,
      corrosionAllowance: 0,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(false);
    if (!res.ok) {
      expect(res.error.code).toBe('PRESSURE_EXCEEDS_THIN_WALL_LIMIT');
    }
  });
});

describe('ug32Head — ASME VIII-1 UG-32', () => {
  it('calculates 2:1 ellipsoidal head thickness per UG-32(d)', () => {
    const res = calculateUg32Head({
      headType: 'ellipsoidal_2_1',
      insideDiameter: 2000,
      designPressure: 2.0,
      designTemperature: 200,
      material: sa516Gr70,
      jointEfficiency: 1.0,
      corrosionAllowance: 0,
      nominalThickness: 16,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.codeParagraph).toBe('UG-32(d)');
      expect(res.data.requiredThickness).toBeCloseTo(14.514, 2);
      expect(res.data.isCodeCompliant).toBe(true);
      expect(res.data.mawp).toBeGreaterThan(2.0);
    }
  });

  it('calculates torispherical F&D head thickness per UG-32(e)', () => {
    const res = calculateUg32Head({
      headType: 'torispherical_fd',
      insideDiameter: 1500,
      designPressure: 1.2,
      designTemperature: 200,
      material: sa516Gr70,
      jointEfficiency: 1.0,
      corrosionAllowance: 2,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.codeParagraph).toBe('UG-32(e)');
      expect(res.data.corrodedCrownRadius).toBe(1502);
      expect(res.data.requiredThickness).toBeGreaterThan(10);
    }
  });
});

describe('ug37Nozzle — ASME VIII-1 UG-37 / UG-40', () => {
  it('flags small openings (<= 60 mm in >10 mm shell) as exempt per UG-36(c)(3)', () => {
    const res = calculateUg37Nozzle({
      designPressure: 2.0,
      designTemperature: 200,
      vesselMaterial: sa516Gr70,
      vesselRequiredThickness: 13.5,
      vesselNominalThickness: 18,
      vesselCorrosionAllowance: 2,
      vesselJointEfficiencyE1: 1.0,
      nozzleMaterial: sa516Gr70,
      nozzleOutsideDiameter: 60.3,
      nozzleNominalThickness: 5.54,
      nozzleJointEfficiency: 1.0,
      nozzleCorrosionAllowance: 2,
      externalProjection: 100,
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.isExemptPerUg36c3).toBe(true);
      expect(res.data.isReinforcementAdequate).toBe(true);
    }
  });

  it('evaluates DN200 nozzle area balance and reinforcement pad contribution', () => {
    const res = calculateUg37Nozzle({
      designPressure: 2.0,
      designTemperature: 200,
      vesselMaterial: sa516Gr70,
      vesselRequiredThickness: 14.5,
      vesselNominalThickness: 18,
      vesselCorrosionAllowance: 2,
      vesselJointEfficiencyE1: 1.0,
      nozzleMaterial: sa516Gr70,
      nozzleOutsideDiameter: 219.1,
      nozzleNominalThickness: 8.18,
      nozzleJointEfficiency: 1.0,
      nozzleCorrosionAllowance: 2,
      externalProjection: 150,
      repad: {
        material: sa516Gr70,
        outsideDiameter: 380,
        thickness: 12,
      },
      weldLegs: {
        leg41: 8,
        leg42: 8,
      },
      unitSystem: 'SI',
    });

    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.data.isExemptPerUg36c3).toBe(false);
      expect(res.data.areas.a5Pad).toBeGreaterThan(0);
      expect(res.data.areas.totalAvailable).toBeGreaterThan(res.data.areas.requiredA);
      expect(res.data.isReinforcementAdequate).toBe(true);
    }
  });
});
